"""
Lee el archivo de datos, sea CSV o Excel.

Todo se lee como TEXTO para no alterar ningún valor
(por ejemplo, que "No disponible" o una celda vacía no se conviertan en otra cosa).
"""
import pandas as pd


def cargar_datos(ruta):
    if ruta.lower().endswith((".xlsx", ".xls")):
        return pd.read_excel(ruta, dtype=str, keep_default_na=False)

    # CSV: detecta solo si el separador es coma o punto y coma (Excel en español usa ";")
    try:
        return pd.read_csv(ruta, dtype=str, keep_default_na=False, sep=None,
                           engine="python", encoding="utf-8-sig")
    except UnicodeDecodeError:
        # Algunos CSV guardados desde Excel en Windows usan otra codificación
        return pd.read_csv(ruta, dtype=str, keep_default_na=False, sep=None,
                           engine="python", encoding="latin-1")
